from flask import Flask, request, jsonify
from .messages import messages_bp

def create_app():
    app = Flask(__name__)

    app.register_blueprint(messages_bp)

    return app
