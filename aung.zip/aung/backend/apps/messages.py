from flask import Blueprint, jsonify, request
from util.utils import validate_json

messages_bp = Blueprint('messages', __name__, url_prefix='/api/messages')

messages = [
    {"name": "Alice", "message": "Hello world!"},
    {"name": "Bob", "message": "React is awesome."},
    {"name": "Charlie", "message": "Flask is great for APIs."},
    {"name": "Diana", "message": "Python is my favorite language."},
    {"name": "Eve", "message": "I love coding!"},
    {"name": "Frank", "message": "APIs are the future of software."},
    {"name": "Grace", "message": "Flask and React make a great combo."},
    {"name": "Hank", "message": "JavaScript is versatile."},
    {"name": "Ivy", "message": "Data science is fascinating."},
    {"name": "Jack", "message": "Machine learning is the next big thing."}
]


@messages_bp.route('', methods=['GET'])
def get_messages():
    return jsonify(messages)
