import { Route, Routes } from "react-router-dom";
import Navbar from "./components/Navbar";
import Form from "./pages/Form";

function App() {
  return (
    <div className="w-full">
      <Navbar />
      <Routes>
        <Route path="/new_message" element={<Form />} />
      </Routes>
    </div>
  );
}

export default App;
