import json
from util import constant
import jsonschema
from jsonschema import validate, ValidationError


def validate_json(data, schema):
    try:
        validate(instance=data, schema=extract_json_schema(schema))
    except jsonschema.exceptions.ValidationError as e:
        raise ValidationError(
            "JSON validation error: {}".format(e.message)) from e


def extract_json_schema(schema):
    json_file_path = "{}/{}.json".format(
        constant.JSON_SCHEMA_DIRECTORY, schema)
    with open(json_file_path, "r") as file:
        data_dict = json.load(file)
    return data_dict
