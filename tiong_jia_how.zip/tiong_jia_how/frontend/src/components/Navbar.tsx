import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <nav className="fixed top-0 left-0 w-full bg-gray-800 text-white p-4 flex justify-evenly">
      <Link to="/new_message">New Message</Link> |{" "}
      <Link to="/messages">Messages</Link>
    </nav>
  );
};

export default Navbar;
